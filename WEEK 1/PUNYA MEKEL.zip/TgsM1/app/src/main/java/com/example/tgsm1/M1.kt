package com.example.tgsm1

import android.media.tv.TvContract.Programs

fun main(){
    var program = true
    var note= mutableListOf<MutableList<String>>()
    println(note)
    var passUser=""
    while (program==true){
        print("""
  My Notes
=============
1. Tambah Note
2. Lihat Note
3. Set Password
4. Exit
=============
>>
    """.trimIndent())
        var inputMenu = readln().toInt()
        if (inputMenu==1){
            var menu1=true
            while (menu1==true){
                var jalan=true
                var isi= mutableListOf<String>()
//                var judul= mutableListOf<String>()
                var temp = mutableListOf<String>()
                println("""
                       My Notes
                    =============
                """.trimIndent())
                print("Judul : ")
                var judulInp :String? = readln()
                if (judulInp==""){
                    judulInp="Untitle #${note.size+1}"
                }
                println("Isi : ")
                var isiInp = readln()
                isi.add(isiInp)
                while (menu1==true){
                    isiInp = readln()
                    isi.add(isiInp)
                    if (isiInp=="<FINISH>"){
                        println("Berhasil menyimpan notes “${judulInp}”!")
                        isi.removeIf { it == "<FINISH>" }
                        temp.add(judulInp!!)
                        temp.addAll(isi)
                        note.add(temp)
                        menu1=false
                        break
                    }
                    else if (isiInp=="<CANCLE>"){
                        println("Berhasil cancel notes “${judulInp}”!")
                        isi.clear()
                        temp.clear()
                        menu1=false
                        break
                    }
                    else{
                        var isiInp = readln()
                        isi.add(isiInp)
                    }
                }
//                note.add(temp)
            }
            println(note)
        }
        else if (inputMenu==2){
            var menu2=true
            while (menu2==true) {
                println(
                    """
                   My Notes
                =============
            """.trimIndent()
                )
                for ((idx, a) in note.withIndex()){
                    println("${idx+1}.${a[0]}")
                }
                println("=============")
                print(">>")
                var inpNote = readln()
                if (inpNote=="back"){
                    menu2=false
                }
                else if(inpNote.contains("search")){
                    var menucari=true
                    while (menucari==true){
                        var kataCari = inpNote.substring(7,inpNote.length)
                        println(
                            """
                   My Notes
                =============
            """.trimIndent()
                        )
                        for ((idx, a) in note.withIndex()){
                            if (a[0].contains(kataCari)) {
                                println("${idx + 1}.${a[0]}")
                            }
                        }
                        println("=============")
                        inpNote= readln()
                        if (inpNote.contains("search")) {
                            kataCari = inpNote.substring(7, inpNote.length)
                        }
                        else if (inpNote=="clear"){
                            menucari=false
                        }
                    }
                }
                else if (inpNote.contains("open")){
                    var nomorIdx = inpNote.substring(5,inpNote.length).toInt()-1
                    var menuDetailNote=true
                    while (menuDetailNote==true){
                        if (nomorIdx>note.size){
                            println("Tidak di Temukan")
                            menuDetailNote=false

                        }
                        println("    ${note[nomorIdx][0]}")
                        println("=================")
                        for (a in 1..note[nomorIdx].size-1){
                            println("${note[nomorIdx][a]}")
                        }
                        println("=================")
                        print(">>")
                        var inpDlm = readln()
                        if (inpDlm=="back"){
                            menuDetailNote=false
                        }
                        else if (inpDlm=="delete"){
                            note.removeAt(nomorIdx)
                            println("Berhasil Delete")
                            menuDetailNote=false
                            break

                        }
                        else if(inpDlm=="encrypt"){
                            val geserMas = 5
                            for (notes in note) {
                                for (i in 1 until notes.size) {
                                    val content = notes[i]
                                    notes[i] = content.map { char ->
                                        when {
                                            char.isLetter() -> ((char + geserMas))
                                            else -> char
                                        }
                                    }.joinToString("")
                                }
                            }
                        }
                        else if(inpDlm=="decrypt"){
                            println("Minta Password :")
                            print(">>")
                            var pass= readln()
                            val geserMas = 5
                            if (pass.equals(passUser)){
                                for (notes in note) {
                                    for (i in 1 until notes.size) {
                                        val content = notes[i]
                                        notes[i] = content.map { char ->
                                            when {
                                                char.isLetter() -> ((char - geserMas))
                                                else -> char
                                            }
                                        }.joinToString("")
                                    }
                                }
                            }
                            else{
                                println("Password Salah")
                            }
                        }

                    }
                }

            }

        }else if (inputMenu==3){
            println("Masukan Input Password User Baru : ")
            passUser= readln()
            println("Password Baru ${passUser}")

        }else if (inputMenu==4){
            program=false
        }
    }
}