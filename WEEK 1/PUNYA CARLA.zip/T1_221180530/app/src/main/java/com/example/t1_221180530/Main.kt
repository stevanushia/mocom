package com.example.t1_221180530

fun main() {
    var listNotes = mutableListOf<MutableList<String>>()
    var boolMenu = true
    var passUser = ""

    while (boolMenu == true) {
        val intro = """
             My Notes
           =============
            1. Tambah Note
            2. Lihat Note
            3. Set Password
            4. Exit
           =============
        """.trimIndent()
        println(intro)
        print(">>")
        var inputMenu:Int? = readln()?.toInt()

        if (inputMenu == 1) {
            var boolCancel = false
            while (boolCancel == false) {
                var boolCheck = true
                var tempNotes = mutableListOf<String>()

                println(
                    """
                         My Notes
                      =============
                    """.trimIndent()
                )
                print("Judul : ")
                var inputJudul = readln()

                if (inputJudul == "") {
                    inputJudul = "Untitled #${listNotes.size + 1}"
                }

                tempNotes.add(inputJudul)
                print("Isi : ")
                while (boolCheck == true) {
                    var inputIsi = readln()

                    if (inputIsi == "<FINISH>") {
                        boolCheck = false
                        listNotes.add(tempNotes)
//                        print(listNotes)
                        println("Berhasil menyimpan notes '$inputJudul'! ")
                    } else if (inputIsi == "<CANCEL>") {
                        boolCancel = true
                        boolCheck = false
                    }
                    else {
                        tempNotes.add(inputIsi)
                    }
                }
            }
        }else if (inputMenu == 2){
            var boolMenu2 = true

            while (boolMenu2 == true) {
                println(" ")
                println("  My Notes")
                println("=============")
                for ((idx, a) in listNotes.withIndex()){
                    println("${idx+1}. ${a[0]}")
                }
                println("=============")
                print(">>")
                var inputLihat = readln()
                if (inputLihat == "back") {
                    boolMenu2 = false
                }else {
                    if (inputLihat.contains("search")) {
                        var judulLihat = inputLihat.substring(7,inputLihat.length)
                        var boolClear = false

                        while (boolClear == false) {
                            println(" ")
                            println(judulLihat)
                            println("=============")
                            for ((idx, a) in listNotes.withIndex()){
                                if (a[0].contains(judulLihat)) {
                                    println("${idx+1}. ${a[0]}")
                                }
                            }
                            println("=============")
                            print(">>")
                            var inputClear = readln()

                            if (inputClear == "clear") {
                                boolClear = true
                            }else {
                                judulLihat = inputClear.substring(7,inputLihat.length)
                                boolClear = false
                            }
                        }
                    }else if (inputLihat.contains("open")) {
                        var lihatNotes = inputLihat.substring(5,inputLihat.length).toInt()
                        var boolOpen = true

                        if (lihatNotes > listNotes.size) {
                            println("Note tidak ditemukan!")
                        }else {
                            while (boolOpen == true) {
                                println(" ")
                                println("${listNotes[lihatNotes-1][0]}")
                                println("=============")
                                for (i in 1..listNotes[lihatNotes-1].size) {
                                    println("${listNotes[lihatNotes-1][i]}")
                                    if (i == listNotes[lihatNotes-1].size - 1) {
                                        break
                                    }
                                }
                                println("=============")
                                print(">>")
                                var inputOpen = readln()

                                if (inputOpen == "back") {
                                    boolOpen = false
                                }else {
                                    if (inputOpen == "encrypt") {
                                        val shiftAmount = 5

                                        for (open in listNotes) {
                                            for (i in 1 until open.size) {
                                                val isi = open[i]
                                                open[i] = isi.map { char ->
                                                    when {
                                                        char.isLetter() -> ((char + shiftAmount))
                                                        else -> char
                                                    }
                                                }.joinToString("")
                                            }
                                        }

                                    }else if (inputOpen == "decrypt") {
                                        print("Masukkan password : ")
                                        var inputPassword = readln()

                                        if (inputPassword == passUser) {
                                            val shiftAmount = 5

                                            for (open in listNotes) {
                                                for (i in 1 until open.size) {
                                                    val isi = open[i]
                                                    open[i] = isi.map { char ->
                                                        when {
                                                            char.isLetter() -> ((char - shiftAmount))
                                                            else -> char
                                                        }
                                                    }.joinToString("")
                                                }
                                            }
                                        }else {
                                            println("Password salah!")
                                        }
                                    }else if (inputOpen == "delete") {
                                        listNotes.removeAt(lihatNotes-1)
                                        println("Berhasil delete note!")
                                        boolOpen = false
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }else if (inputMenu == 3){
            print("Masukkan password baru : ")
            passUser = readln()
            println("Berhasil memasukkan password baru!")
        }else if (inputMenu == 4){
            return
        }
    }

}