package com.example.projectminggu5

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class HomeFragment : Fragment() {
    lateinit var txtPengeluaran: TextView
    lateinit var btnSort: Button
    lateinit var rvPengeluaran: RecyclerView
    lateinit var homeAdapter: HomeAdapter
    lateinit var layoutManager: RecyclerView.LayoutManager
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_home, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
//        btnToAdd = view.findViewById(R.id.btnToAdd)
//        btnSort = view.findViewById(R.id.btnSort)
        rvPengeluaran = view.findViewById(R.id.rvPengeluaran)
        txtPengeluaran = view.findViewById(R.id.txtTotalPengeluaran)


        val menus:MutableList<Pengeluaran> = MockDB.listPengeluaran

        homeAdapter = HomeAdapter(menus)
        layoutManager = LinearLayoutManager(requireContext(), LinearLayoutManager.VERTICAL, false)
        rvPengeluaran.adapter = homeAdapter
        rvPengeluaran.layoutManager = layoutManager
        var total = 0
        for(i in menus){
            total += i.jumlah
        }
        txtPengeluaran.setText(total.toString())

//        binding.btnCart.setOnClickListener {
//            val intent = Intent(this, CartActivity::class.java)
//            startActivity(intent)
//        }
    }
}