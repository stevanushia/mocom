package com.example.projectminggu5

class MockDB {
    companion object{
        val listPengeluaran:MutableList<Pengeluaran> = mutableListOf()

        fun addPengeluaran(i:Pengeluaran){
            listPengeluaran.add(i)
        }

    }
}