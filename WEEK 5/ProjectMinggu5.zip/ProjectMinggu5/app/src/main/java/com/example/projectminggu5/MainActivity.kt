package com.example.projectminggu5

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentContainerView
import androidx.navigation.fragment.findNavController

class MainActivity : AppCompatActivity() {
    lateinit var container: FragmentContainerView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        container = findViewById(R.id.fragment_container)



    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_example, menu)
        return super.onCreateOptionsMenu(menu)

    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.mi_home->{
                //ini untuk aksi mengganti fragment tanpa mengirimkan arguments
                container.getFragment<Fragment>().findNavController().navigate(R.id.action_global_homeFragment)
            }
            else->{
                container.getFragment<Fragment>().findNavController().navigate(R.id.action_global_tambahFragment)
            }
        }
        return super.onOptionsItemSelected(item)
    }
}