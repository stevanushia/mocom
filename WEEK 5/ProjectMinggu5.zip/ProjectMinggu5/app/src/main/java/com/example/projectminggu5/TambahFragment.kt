package com.example.projectminggu5

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast


class TambahFragment : Fragment() {

    lateinit var edtNama : EditText
    lateinit var edtJumlah : EditText
    lateinit var btnReset : Button
    lateinit var btnTambah : Button
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_tambah, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        btnReset = view.findViewById(R.id.btnReset)
        btnTambah = view.findViewById(R.id.btnTambah)
        edtNama = view.findViewById(R.id.edtNama)
        edtJumlah = view.findViewById(R.id.edtJumlah)
         btnReset.setOnClickListener {
            edtNama.text = null
             edtJumlah.text = null
         }

        btnTambah.setOnClickListener {
            if (edtNama.text.toString() == "" || edtJumlah.text.toString() == ""){
                Toast.makeText(requireContext(), "ISI DULU BOSS", Toast.LENGTH_SHORT).show()
            }
            else{
                MockDB.addPengeluaran(Pengeluaran(edtNama.text.toString(), edtJumlah.text.toString().toInt()))

            }

        }

    }
}