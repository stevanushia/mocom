package com.example.projectminggu5

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class HomeAdapter(
    val data: MutableList<Pengeluaran>,
//    var onOrderClickListener: ((MenuCatalog)-> Unit) ?= null,
//    var catalogActivityContext: Context
) : RecyclerView.Adapter<HomeAdapter.ViewHolder>(){

    class ViewHolder(val row: View) : RecyclerView.ViewHolder(row){
        val nomorPengeluaran: TextView = row.findViewById(R.id.txtNomorPengeluaran)
        val namaPengeluaran: TextView = row.findViewById(R.id.txtNamaPengeluaran)
        val jumlahPengeluaran: TextView = row.findViewById(R.id.txtJumlahPengeluaran)
        val btnDelete: Button = row.findViewById(R.id.btnDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val layout = LayoutInflater.from(parent.context).inflate(
            R.layout.rv_pengeluaran, parent, false
        )
        return ViewHolder(layout)
    }

    override fun getItemCount(): Int {
        return data.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val pengeluaran = data[position]
        holder.nomorPengeluaran.text = "Pengeluaran 1"
        holder.namaPengeluaran.text = pengeluaran.nama
        holder.jumlahPengeluaran.text = pengeluaran.jumlah.toString()
        holder.btnDelete.setOnClickListener {
//            val intent = Intent(catalogActivityContext, DetailActivity::class.java)
//            intent.putExtra("harga",menu.harga)
//            intent.putExtra("name",menu.nama)
//            intent.putExtra("image",menu.gambar)
//            catalogActivityContext.startActivity(intent)

            data.removeAt(holder.adapterPosition)
            notifyItemRemoved(holder.adapterPosition)
        }
    }


}