package com.example.projectminggu5

data class Pengeluaran(val nama: String, val jumlah: Int)
