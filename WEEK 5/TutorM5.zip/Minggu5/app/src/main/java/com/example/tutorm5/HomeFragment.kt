package com.example.tutorm5

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.LayoutManager

class HomeFragment : Fragment() {
    // Deklarasi component
    lateinit var btnToAdd: Button
    lateinit var btnSort:Button
    lateinit var rvMahasiswa: RecyclerView
    lateinit var mhsAdapter: MahasiswaAdapter
    lateinit var layoutManager: LayoutManager

    var sortMode: Int = 1

    //method untuk melakukan inflate layout ke fragment
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        var view = inflater.inflate(R.layout.fragment_home, container, false)
        return view
    }


    //method ini dijalankan sesudah onCreateView
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Menghubungkan seluruh component
        btnToAdd = view.findViewById(R.id.btnToAdd)
        btnSort = view.findViewById(R.id.btnSort)
        rvMahasiswa = view.findViewById(R.id.rvMahasiswa)


        /**
         * Button di bawah ini digunakan untuk memindahkan halaman ke arah CreateFragment
         * Untuk memindahkan kita perlu menggunakan fungsi navigate dari Navigation Controller
         *
         * findNavController: fungsi untuk mendapatkan Navigation Controller
         * navigate: fungsi dari Navigation Controller untuk memindahkan menggunakan action yang sesuai
         *           pada fungsi ini dapat dimasukkan ID action yang sudah di declare pada Navigation Graph
         */
        btnToAdd.setOnClickListener {
            findNavController().navigate(R.id.action_global_createFragment)
        }


        /**
         * Pada fragment, kita tidak bisa menggunakan "this" untuk mengisi context,
         * hal ini dikarenakan, context biasanya diisi activity.
         *
         * Karena kita tidak code di activity, kita perlu menggunakan requireContext()
         * requireContext akan mengambil context dari fragment tersebut
         * */
        layoutManager = LinearLayoutManager(requireContext(),LinearLayoutManager.VERTICAL,false)
        mhsAdapter = MahasiswaAdapter(MockDB.listMhs) { mhs ->
            //untuk memberikan arguments pada action navigation dapat dilakukan seperti ini
            /**
             * fungsi navigate pada Navigation Controller dapat menerima sebuah object bertipe NavDirections
             * NavDirections merupakan object direction yang dapat menerima sebuah argument.
             *
             * Untuk mendapatkan NavDirections, kita bisa mengambil melalui sebuah class yang bernama "<NamaFragment>Directions"
             * Dari class tersebut kita dapat mengambil sebuah action yang sudah didaftarkan pada Navigation Graph
             *
             * Action akan berbentuk sebuah method yang dapat menerima argumen.
             * Action akan bernama sama dengan action yang sudah dibuat, tetapi dengan format camelCase
             * Setelah mendapatkan object navDirections, masukkan object tersebut pada fungsi navigate pada NavController
             */

            val action = HomeFragmentDirections.actionHomeFragmentToCreateFragment(mhs.nrp)
            findNavController().navigate(action)
        }


        /**
         * Setting Adapter dan LayoutManager RecyclerView
         * Disini tidak bisa menggunakan fungsi apply (recyclerView tidak keluar)
         * Berikut merupakan contoh yang SALAH:
         *
         *   rvMahasiswa.apply {
         *     this.layoutManager = layoutManager
         *     this.adapter = mhsAdapter
         *   }
         *
         */
        rvMahasiswa.adapter = mhsAdapter
        rvMahasiswa.layoutManager = layoutManager


        btnSort.setOnClickListener {
            if(sortMode==1){
                sortMode = 0
                MockDB.listMhs.sortByDescending {
                        mhs-> mhs.nrp + mhs.nama
                }
                btnSort.text = "Sort Ascending"
            }else {
                sortMode = 1
                MockDB.listMhs.sortBy {
                        mhs-> mhs.nrp + mhs.nama
                }
                btnSort.text = "Sort Descending"
            }
            mhsAdapter.notifyDataSetChanged()
        }
    }

}