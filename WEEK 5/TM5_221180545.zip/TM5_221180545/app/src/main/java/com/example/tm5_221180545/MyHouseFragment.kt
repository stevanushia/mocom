package com.example.tm5_221180545

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MyHouseFragment : Fragment() {
    lateinit var rvMyHouse: RecyclerView
    lateinit var myHouseAdapter: MyHouseAdapter
    lateinit var layoutManager: RecyclerView.LayoutManager
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_my_house, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        rvMyHouse = view.findViewById(R.id.rvMyHouse)

        val menus:MutableList<Rumah> = MockDB.listMyHouse

        myHouseAdapter = MyHouseAdapter(menus)
        layoutManager = LinearLayoutManager(requireContext(), LinearLayoutManager.VERTICAL, false)
        rvMyHouse.adapter = myHouseAdapter
        rvMyHouse.layoutManager = layoutManager
    }
}