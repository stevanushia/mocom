package com.example.tm5_221180545

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class MyHouseAdapter(
    val data: MutableList<Rumah>
) : RecyclerView.Adapter<MyHouseAdapter.ViewHolder>() {
    class ViewHolder(val row: View) : RecyclerView.ViewHolder(row){
        val img_rv_my_house: ImageView = row.findViewById(R.id.img_rv_myHouse)
        val nama_myHouse: TextView = row.findViewById(R.id.txt_rv_myHouse_nama)
        val harga_myHouse: TextView = row.findViewById(R.id.txt_rv_myHouse_harga)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyHouseAdapter.ViewHolder {
        val layout = LayoutInflater.from(parent.context).inflate(
            R.layout.rv_my_house, parent, false
        )
        return MyHouseAdapter.ViewHolder(layout)
    }

    override fun getItemCount(): Int {
        return data.size
    }

    override fun onBindViewHolder(holder: MyHouseAdapter.ViewHolder, position: Int) {
        val catalog = data[position]
        holder.nama_myHouse.text = catalog.alamat
        holder.harga_myHouse.text = "Rp. ${catalog.harga}"
        holder.img_rv_my_house.setImageResource(catalog.gambar)
    }
}