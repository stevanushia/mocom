package com.example.tm5_221180545

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class CatalogAdapter(
    val data: MutableList<Rumah>,
): RecyclerView.Adapter<CatalogAdapter.ViewHolder>() {
    class ViewHolder(val row: View) : RecyclerView.ViewHolder(row){
        val img_rv_catalog: ImageView = row.findViewById(R.id.img_rv_catalog)
        val namaCatalog: TextView = row.findViewById(R.id.txt_rv_catalog_nama)
        val hargaCatalog: TextView = row.findViewById(R.id.txt_rv_catalog_harga)
        val btnBuy: Button = row.findViewById(R.id.btnBuy_rv_catalog)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val layout = LayoutInflater.from(parent.context).inflate(
            R.layout.rv_catalog, parent, false
        )
        return ViewHolder(layout)
    }

    override fun getItemCount(): Int {
        return data.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val catalog = data[position]
        holder.namaCatalog.text = catalog.alamat
        holder.hargaCatalog.text = "Rp. ${catalog.harga}"
        holder.img_rv_catalog.setImageResource(catalog.gambar)

        holder.btnBuy.setOnClickListener {
            MockDB.addMyHouse(catalog)
            data.removeAt(holder.adapterPosition)
            notifyItemRemoved(holder.adapterPosition)
        }
    }
}