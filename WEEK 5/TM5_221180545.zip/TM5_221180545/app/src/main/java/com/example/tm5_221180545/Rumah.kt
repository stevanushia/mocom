package com.example.tm5_221180545

data class Rumah(val gambar:Int, val alamat:String, val harga:Int)
