package com.example.tm5_221180545

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.tm5_221180545.databinding.ActivityLoginBinding

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnLogin.setOnClickListener {
            var username = binding.edtUsername.text.toString()
            var password = binding.edtPassword.text.toString()
            if ( username != "" && password != ""){
                if (username == "investor" && password == "kayaraya"){
                    binding.edtUsername.text = null
                    binding.edtPassword.text = null
                    val intent = Intent(this, MainActivity::class.java)
                    startActivity(intent)
                }
                else{
                    Toast.makeText(this, "Uhm.. try again?", Toast.LENGTH_SHORT).show()
                }
            }
            else{
                Toast.makeText(this, "PLEASE FILL OUT THE FORM", Toast.LENGTH_SHORT).show()
            }
        }
    }
}