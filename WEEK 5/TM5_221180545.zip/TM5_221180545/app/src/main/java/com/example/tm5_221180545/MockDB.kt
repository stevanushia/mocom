package com.example.tm5_221180545

class MockDB {
    companion object{
        val listMyHouse:MutableList<Rumah> = mutableListOf()
        val listCatalog: MutableList<Rumah> = mutableListOf(
            Rumah(R.drawable.burning_house, "Burning House", 69000),
            Rumah(R.drawable.car_house, "Broken Car Aesthetic", 40000),
            Rumah(R.drawable.dirt_house, "Dirt House", 145000),
            Rumah(R.drawable.family_guy_house, "Peter's House", 35000),
            Rumah(R.drawable.hamster_house, "Hamster House", 56000),
            Rumah(R.drawable.hobbit_house, "Hobbit House", 20000),
            Rumah(R.drawable.slim_house, "Slim House", 200000),
            Rumah(R.drawable.upside_down_house, "Upside Down House", 14000),
        )
        fun addCatalog(m:Rumah){
            listCatalog.add(m)
        }

        fun addMyHouse(i:Rumah){
            listMyHouse.add(i)
        }
    }
}