package com.example.kuncim6

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import androidx.databinding.DataBindingUtil
import com.example.kuncim6.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    val vm:TravelViewModel by viewModels()
    lateinit var binding:ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)

        binding.rbBali.isChecked = true
        vm.updateSubtotal()

        /**
         * Observer untuk durasi, anggota anak, dan anggota dewasa
         */
        vm.durasi.observe(this){
            binding.tvDurasi.text = "$it"
        }
        vm.anak.observe(this){
            binding.tvAnak.text = "$it"
        }
        vm.dewasa.observe(this){
            binding.tvDewasa.text = "$it"
        }

        /**
         * Observer untuk Subtotal dan total
         */
        vm.tiket.observe(this){
            binding.tvTiket.text = "$it"
        }
        vm.harian.observe(this){
            binding.tvHarian.text = "$it"
        }
        vm.lain.observe(this){
            binding.tvLain.text = "$it"
        }
        vm.total.observe(this){
            binding.tvTotal.text = "$it"
        }



        /**
         * Handler untuk button durasi
         */
        binding.btIncDurasi.setOnClickListener {
            vm.tambahHari()
        }
        binding.btDecDurasi.setOnClickListener {
            vm.kurangiHari()
        }


        /**
         * Handler untuk button anak
         */
        binding.btIncAnak.setOnClickListener {
            vm.tambahAnak()
        }
        binding.btDecAnak.setOnClickListener {
            vm.kurangiAnak()
        }


        /**
         * Handler untuk button dewasa
         */
        binding.btIncDewasa.setOnClickListener {
            vm.tambahDewasa()
        }
        binding.btDecDewasa.setOnClickListener {
            vm.kurangiDewasa()
        }


        binding.rgDestinasi.setOnCheckedChangeListener { radioGroup, i ->
            when(radioGroup.checkedRadioButtonId){
                R.id.rbBali -> vm.gantiDestinasi("Bali")
                R.id.rbMalaysia -> vm.gantiDestinasi("Malaysia")
                R.id.rbSingapore -> vm.gantiDestinasi("Singapore")
            }
        }

        binding.cbSarapan.isChecked = vm.sarapan.value!!
        binding.cbSarapan.setOnClickListener {
            vm.centangSarapan()
        }
        binding.cbMakanMalam.isChecked = vm.makanmalam.value!!
        binding.cbMakanMalam.setOnClickListener {
            vm.centangMakanMalam()
        }
    }
}