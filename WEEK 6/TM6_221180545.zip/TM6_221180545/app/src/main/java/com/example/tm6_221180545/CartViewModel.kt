package com.example.tm6_221180545

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class CartViewModel: ViewModel() {
    var total: MutableLiveData<Int> = MutableLiveData(0)

    fun calculateTotal(){
        total.value = 0
        for (i in MockDB.listCart){
            total.value = total.value?.plus(i.harga)
        }
    }
}