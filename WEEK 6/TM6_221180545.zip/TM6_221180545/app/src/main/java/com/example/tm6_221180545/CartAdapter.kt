package com.example.tm6_221180545

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class CartAdapter(
    val data: MutableList<Kopi>,
    var onMin: ((Kopi) -> Unit)? = null,
    var onPlus: ((Kopi) -> Unit)? = null,
    ): RecyclerView.Adapter<CartAdapter.ViewHolder>() {

    class ViewHolder(val row: View):RecyclerView.ViewHolder(row){
        val txtNamaCart = row.findViewById<TextView>(R.id.txtNamaCart)
        val txtHargaCart = row.findViewById<TextView>(R.id.txtHargaCart)
        val txtCtrCart = row.findViewById<TextView>(R.id.txtCtrCart)
        val btnMinCart = row.findViewById<ImageButton>(R.id.btnMinCart)
        val btnPlusCart = row.findViewById<ImageButton>(R.id.btnPlusCart)
        val imgCart = row.findViewById<ImageView>(R.id.imgCart)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CartAdapter.ViewHolder {
        val layout = LayoutInflater.from(parent.context).inflate(R.layout.cart_rv_layout, parent, false)
        return CartAdapter.ViewHolder(layout)
    }

    override fun getItemCount(): Int {
        return data.size
    }

    override fun onBindViewHolder(holder: CartAdapter.ViewHolder, position: Int) {
        val menu = data[position]
        holder.txtNamaCart.text = menu.nama
        holder.txtHargaCart.text = "Rp. ${menu.harga}"
        holder.txtCtrCart.text = menu.qty.toString()
        holder.imgCart.setImageResource(menu.gambar)
        holder.btnMinCart.setOnClickListener {
            onMin?.invoke(menu)
        }
        holder.btnPlusCart.setOnClickListener {
            onPlus?.invoke(menu)
        }

    }

}