package com.example.tm6_221180545

import android.util.Log
import android.widget.RadioButton
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class MainViewModel: ViewModel()  {
    var qty: MutableLiveData<Int> = MutableLiveData(1)
    var totalHargaItem: MutableLiveData<Int> = MutableLiveData(0)
    var feeAddons:Int = 0
    var hargaItem:Int = 0


    fun tambahQty(){
        qty.value = qty.value!! + 1
    }
    fun kurangQty(){
        if (qty.value!! > 1){
            qty.value = qty.value!! - 1
        }
    }

    fun calculatePrice() {
        Log.d("calculate", totalHargaItem.value.toString())
        totalHargaItem.value = 0
        totalHargaItem.value = qty.value!! * hargaItem + feeAddons
    }

    fun addCart(item:Kopi){
        MockDB.addCart(item)
    }
}