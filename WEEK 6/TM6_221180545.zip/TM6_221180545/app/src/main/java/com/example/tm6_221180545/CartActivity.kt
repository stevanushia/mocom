package com.example.tm6_221180545

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.activity.viewModels
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.tm6_221180545.databinding.ActivityCartBinding
import com.example.tm6_221180545.databinding.ActivityMainBinding

class CartActivity : AppCompatActivity() {
    private lateinit var binding: ActivityCartBinding
    private val vm:CartViewModel by viewModels()
    lateinit var rvCart: RecyclerView
    lateinit var cartAdapter: CartAdapter
    lateinit var layoutManager: RecyclerView.LayoutManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this,R.layout.activity_cart)
        rvCart = binding.rvCart

        val menus:MutableList<Kopi> = MockDB.listCart

        cartAdapter = CartAdapter(menus)
        layoutManager = LinearLayoutManager(baseContext, LinearLayoutManager.VERTICAL, false)
        rvCart.adapter = cartAdapter
        rvCart.layoutManager = layoutManager


        binding.btnBack.setOnClickListener {
            finish()
        }

        binding.btnOrder.setOnClickListener {
            Toast.makeText(baseContext, "Anda harus membayar sebesar ${vm.total.value!!}", Toast.LENGTH_SHORT).show()
            MockDB.listCart.clear()
            cartAdapter.notifyDataSetChanged()
            vm.total.value = 0
        }

        vm.total.observe(this){
            binding.txtTotal.text = "Rp. ${it}"
        }

        vm.calculateTotal()

        cartAdapter.onMin = {
            it.qty--
            if (it.qty == 0){
                for (i in MockDB.listCart){
                    if (i == it){
                        MockDB.listCart.remove(i)
                        break
                    }
                }
            }
            else{
                for (i in MockDB.listKopi){
                    if (i.nama == it.nama){
                        it.harga-=i.harga
                        break
                    }
                }
            }
            vm.calculateTotal()
            cartAdapter.notifyDataSetChanged()

        }
        cartAdapter.onPlus = {
            it.qty++
            for (i in MockDB.listKopi){
                if (i.nama == it.nama){
                    it.harga+=i.harga
                    break
                }
            }
            vm.calculateTotal()
            cartAdapter.notifyDataSetChanged()
        }
    }
}