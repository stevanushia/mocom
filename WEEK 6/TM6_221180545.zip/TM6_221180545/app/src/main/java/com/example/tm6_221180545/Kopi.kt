package com.example.tm6_221180545

data class Kopi (val gambar:Int, val nama:String, var harga:Int, var qty: Int = 0)
