package com.example.tm6_221180545

import android.view.LayoutInflater
import android.view.View
import android.view.View.OnClickListener
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class MainAdapter(
    val data: MutableList<Kopi>,

) : RecyclerView.Adapter<MainAdapter.ViewHolder>(){
    private var onClickListener: OnClickListener? = null

    class ViewHolder(val row: View):RecyclerView.ViewHolder(row){
        val txt_rv_menu = row.findViewById<TextView>(R.id.txt_rv_menu)
        val txt_rv_price = row.findViewById<TextView>(R.id.txt_rv_price)
        val img_rv = row.findViewById<ImageView>(R.id.img_rv)
    }
    fun setOnClickListener(onClickListener: OnClickListener) {
        this.onClickListener = onClickListener
    }

    // onClickListener Interface
    interface OnClickListener {
        fun onClick(position: Int, model: Kopi)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val layout = LayoutInflater.from(parent.context).inflate(R.layout.main_rv_layout, parent, false)
        return ViewHolder(layout)
    }

    override fun getItemCount(): Int {
        return data.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val menu = data[position]
        holder.txt_rv_menu.text = menu.nama
        holder.txt_rv_price.text = "Rp. ${menu.harga}"
        holder.img_rv.setImageResource(menu.gambar)
        holder.itemView.setOnClickListener {
            if (onClickListener != null) {
                onClickListener!!.onClick(position, menu)
            }
        }
    }
}