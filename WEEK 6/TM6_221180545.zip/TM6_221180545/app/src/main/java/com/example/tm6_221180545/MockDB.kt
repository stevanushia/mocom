package com.example.tm6_221180545

class MockDB {
    companion object{
        val listCart:MutableList<Kopi> = mutableListOf()
        val listKopi: MutableList<Kopi> = mutableListOf(
            Kopi(R.drawable.kopi_abc, "Kopi ABC", 5000),
            Kopi(R.drawable.copy_cat, "Copy Cat", 10000),
            Kopi(R.drawable.empty_coffee, "Kopinya Habis", 15000),
            Kopi(R.drawable.relatable_coffee, "Kopikir-pikir Dulu", 20000),
        )
        fun addKopi(m:Kopi){
            listKopi.add(m)
        }

        fun addCart(i:Kopi){
            var found = false
            for (item in listCart){
                if (item.nama == i.nama){
                    item.qty += i.qty
                    item.harga += i.harga
                    found = true
                    break
                }
            }

            if (!found){
                listCart.add(i)
            }
        }
    }
}