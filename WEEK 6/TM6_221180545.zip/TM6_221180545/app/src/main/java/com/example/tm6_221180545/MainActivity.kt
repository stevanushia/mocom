package com.example.tm6_221180545

import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.viewModels
import androidx.annotation.RequiresApi
import androidx.core.view.isVisible
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.tm6_221180545.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding:ActivityMainBinding
    private val vm:MainViewModel by viewModels()
    lateinit var rvCatalog: RecyclerView
    lateinit var mainAdapter: MainAdapter
    lateinit var layoutManager: RecyclerView.LayoutManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this,R.layout.activity_main)
        rvCatalog = binding.rvMain

        val menus:MutableList<Kopi> = MockDB.listKopi

        mainAdapter = MainAdapter(menus)
        layoutManager = LinearLayoutManager(baseContext, LinearLayoutManager.VERTICAL, false)
        rvCatalog.adapter = mainAdapter
        rvCatalog.layoutManager = layoutManager

        var currentPrice = 0
        var selected:Kopi
        var img = 0
        var namaMenu = ""

        mainAdapter.setOnClickListener(object :
            MainAdapter.OnClickListener {
            override fun onClick(position: Int, model: Kopi) {
                selected = MockDB.listKopi[position]

                binding.imgMain.setImageResource(selected.gambar)
                binding.txtSelectedNamaMenu.text = selected.nama
                binding.txtSelectedHarga.isVisible = true
                binding.txtSelectedHarga.text = "${selected.harga.toString()}"
                binding.txtRp.isVisible = true
                binding.rdbGroupSelectedSize.isVisible = true
                binding.rdbGroupSelectedSize.clearCheck()

                img = selected.gambar
                namaMenu = selected.nama

                vm.qty.value = 1
                vm.feeAddons = 0
                vm.hargaItem = selected.harga
                vm.totalHargaItem.value = selected.harga
            }
        })


        vm.qty.observe(this){
            binding.txtCtr.text = "${it}"
        }
        vm.totalHargaItem.observe(this){
            binding.txtSelectedHarga.text = "${it}"
        }

        binding.btnMinCtr.setOnClickListener {
            vm.kurangQty()
            vm.calculatePrice()
        }

        binding.btnPlusCtr.setOnClickListener {
            vm.tambahQty()
            vm.calculatePrice()
        }

        binding.rdbGroupSelectedSize.setOnCheckedChangeListener { group, checkedId ->
            when (checkedId) {
                R.id.rdbTall -> vm.feeAddons = 0
                R.id.rdbGrande-> vm.feeAddons = 5000
                R.id.rdbVenti-> vm.feeAddons = 10000
            }
            vm.calculatePrice()
        }

        binding.btnAddToCart.setOnClickListener {
            vm.addCart(Kopi(img, binding.txtSelectedNamaMenu.text.toString(), binding.txtSelectedHarga.text.toString().toInt(), vm.qty.value!!))
            Log.d("cart", MockDB.listCart.toString())
            Toast.makeText(this, "$namaMenu Berhasil Ditambahkan!", Toast.LENGTH_SHORT).show()
            binding.imgMain.setImageResource(R.drawable.placehoder_image)
            binding.txtSelectedNamaMenu.text = "Choose a menu"
            binding.txtSelectedHarga.isVisible = false
            binding.rdbGroupSelectedSize.isVisible = false
            binding.txtRp.isVisible = false
            vm.qty.value = 1
        }

        binding.btnCart.setOnClickListener {
            startActivity(Intent(baseContext, CartActivity::class.java))
        }


    }
}