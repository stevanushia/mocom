package com.example.kuncim6

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import androidx.databinding.DataBindingUtil
import com.example.kuncim6.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    val vm:TravelViewModel by viewModels()
    lateinit var binding:ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)

        binding.vm = vm
        binding.lifecycleOwner = this

        binding.rbBali.isChecked = true
        vm.updateSubtotal()

        binding.rgDestinasi.setOnCheckedChangeListener { radioGroup, i ->
            when(radioGroup.checkedRadioButtonId){
                R.id.rbBali -> vm.gantiDestinasi("Bali")
                R.id.rbMalaysia -> vm.gantiDestinasi("Malaysia")
                R.id.rbSingapore -> vm.gantiDestinasi("Singapore")
            }
        }
    }
}