package com.example.kuncim6

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class TravelViewModel : ViewModel() {
    var destinasi: MutableLiveData<String> = MutableLiveData("Bali")

    var durasi: MutableLiveData<Int> = MutableLiveData(1)

    var sarapan: MutableLiveData<Boolean> = MutableLiveData(false)
    var makanmalam: MutableLiveData<Boolean> = MutableLiveData(false)

    var anak: MutableLiveData<Int> = MutableLiveData(0)
    var dewasa: MutableLiveData<Int> = MutableLiveData(1)

    var tiket: MutableLiveData<Int> = MutableLiveData(0)
    var harian: MutableLiveData<Int> = MutableLiveData(0)
    var lain: MutableLiveData<Int> = MutableLiveData(0)
    var total: MutableLiveData<Int> = MutableLiveData(0)

    fun tambahHari(){
        durasi.value = durasi.value!! + 1
        updateSubtotal()
    }

    fun kurangiHari(){
        if(durasi.value!! > 1){
            durasi.value = durasi.value!! - 1
            updateSubtotal()
        }
    }

    fun tambahAnak(){
        anak.value = anak.value!! + 1
        updateSubtotal()
    }
    fun tambahDewasa(){
        dewasa.value = dewasa.value!! + 1
        updateSubtotal()
    }

    fun kurangiAnak(){
        if(anak.value!! > 0){
            anak.value =anak.value!! - 1
            updateSubtotal()
        }
    }
    fun kurangiDewasa(){
        if(anak.value!! > 1){
            anak.value =anak.value!! - 1
            updateSubtotal()
        }
    }

    fun centangSarapan(){
        sarapan.value = !sarapan.value!!
        updateSubtotal()
    }
    fun centangMakanMalam(){
        makanmalam.value = !makanmalam.value!!
        updateSubtotal()
    }
    fun gantiDestinasi(dest:String){
        destinasi.value = dest
        updateSubtotal()
    }

    fun getHargaTiket():Int{
        return when(destinasi.value!!){
            "Bali" -> 2_000_000
            "Malaysia" -> 3_000_000
            "Singapore" -> 5_000_000
            else -> 0
        }
    }

    fun getBiayaHarian():Int{
        return when(destinasi.value!!){
            "Bali" -> 1_600_000
            "Malaysia" -> 1_200_000
            "Singapore" -> 2_000_000
            else -> 0
        }
    }

    fun updateSubtotal(){
        tiket.value = getHargaTiket() * (anak.value!! + dewasa.value!!)
        harian.value = ((getBiayaHarian() * dewasa.value!!) + (getBiayaHarian() * anak.value!! / 2)) * durasi.value!!
        lain.value = 0
        if(durasi.value!! <= 7){
            if(sarapan.value!! == true){
                lain.value = lain.value!! + 50000 * (anak.value!! + dewasa.value!!) * durasi.value!!
            }
            if(makanmalam.value!! == true){
                lain.value = lain.value!! + 100000 * dewasa.value!! * durasi.value!!
            }
        }
        total.value = tiket.value!! + harian.value!! + lain.value!!
    }
}