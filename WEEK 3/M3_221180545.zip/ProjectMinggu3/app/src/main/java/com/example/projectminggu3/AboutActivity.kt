package com.example.projectminggu3

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.RadioButton
import com.example.projectminggu3.databinding.ActivityAboutBinding
import com.example.projectminggu3.databinding.ActivityMainBinding

class AboutActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAboutBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about)

        binding = ActivityAboutBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.txtDetailAbout.text = "Cak Lontong dikenal sebagai komedian dengan lawakan baku terstruktur dengan logika absurd yang siap membuat penontonnya berpikir. Pria yang memiliki nama asli Lies Hartono ini pun dikenal masyarakat lewat acara-acara televisi yang dipandunya. Ia menjadi salah satu pelawak tunggal atau komika Indonesia yang sukses."

        binding.rdbCakLontong.setOnCheckedChangeListener{ buttonView, isChecked ->
            // buttonView merujuk pada radiobutton sendiri
            // panggil function buatan sendiri
            this.setDeskripsiValue(binding.rdbCakLontong, binding.rdbPembuat)
        }
        binding.rdbPembuat.setOnCheckedChangeListener{ buttonView, isChecked ->
            this.setDeskripsiValue(binding.rdbCakLontong, binding.rdbPembuat)
        }

        binding.btnBack.setOnClickListener(){
            finish()
        }



    }

    fun setDeskripsiValue(rad1: RadioButton, rad2: RadioButton) {
        if (rad1.isChecked){
            binding.txtDetailAbout.text = "Cak Lontong dikenal sebagai komedian dengan lawakan baku terstruktur dengan logika absurd yang siap membuat penontonnya berpikir. Pria yang memiliki nama asli Lies Hartono ini pun dikenal masyarakat lewat acara-acara televisi yang dipandunya. Ia menjadi salah satu pelawak tunggal atau komika Indonesia yang sukses."
            // ubah warna button
            // bisa custom warna dengan menambah warna pada folder res -> values -> colors.xml
        }
        else{
            binding.txtDetailAbout.text = """
                Nama : Stevanus Fernandes Hia
                NRP : 221180545
                JURUSAN : SIB
            """.trimIndent()
        }
    }
}