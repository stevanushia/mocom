package com.example.projectminggu3

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore.Audio.Radio
import android.widget.Button
import android.widget.CheckBox
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import com.example.projectminggu3.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    var score = -5
    val list_pertanyaan= arrayOf(
        arrayOf("Burung terbang dengan", "semaunya"),
        arrayOf("orang batuk dilarang minum ...", "bensin"),
        arrayOf("Yang sering mendapat nilai 100 saat ulangan disebut?", "kertas"),
        arrayOf("Seseorang yang memimpin sebuah kelurahan, biasanya dipanggil pak?", "noleh"),
        arrayOf("Senikmat-nikmatnya makan di luar lebih nikmat makan di?", "telan"),
        arrayOf("Ikan bernapas di air dengan?", "tenang"),
        arrayOf("Binatang yang hinggap di makanan?", "lapar"),
        arrayOf("Di dalam perpustakaan tidak boleh?", "mandi"),
        arrayOf("Yang dibalik selalu rusak?", "kasur"),
        arrayOf("Kita tidak bisa menelepon, kalau handphone-nya nggak ada?", "angka"),
        arrayOf("Burung bisa terbang karena memiliki?", "bakat"),
        arrayOf("Yang dibeli seorang cowok untuk pasangannya di saat Valentine biasanya?", "bayar"),
        arrayOf("Neil Amstrong adalah astronot yang pernah menginjakkan kakinya di?", "rumah"),
        arrayOf("Seorang barber mencukur rambut pelanggan dengan?", "gantian"),
        arrayOf("Saat naik pesawat kita dilarang membawa?", "sendiri"),
        arrayOf("Setelah lulus SMA biasanya lanjut?", "pulang"),
        arrayOf("Bertamu lebih dari 2x24 jam harus?", "makan"),
        arrayOf("Kalo haus minum?", "aja"),
    )

    var currentQuestion = ""
    var currentAnswer = ""

    private lateinit var binding:ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        updateScore()
        randomQuestion()

        binding.btnTebak.setOnClickListener {
            if (binding.txtInputAnswer.text.toString() == currentAnswer){
                Toast.makeText(this, "Jawaban Anda Benar!", Toast.LENGTH_SHORT).show()
                updateScore()
                randomQuestion()
                binding.txtInputAnswer.text = null
            }
            else{
                Toast.makeText(this, "Jawaban Anda Salah!", Toast.LENGTH_SHORT).show()

            }
        }

        binding.btnTempe.setOnClickListener {
            binding.txtHint.text = "JAWABAN : $currentAnswer"
        }



        binding.btnAbout.setOnClickListener(){
            // intent berfungsi untuk mempersiapkan activity lain yang akan dipanggil
            val intent = Intent(this, AboutActivity::class.java)
//            intent.putExtra("namaMahasiswa1",txtNama.text.toString())
            // Intent(activity asal, activity tujuan)
            // startActivity untuk menampilkan
            startActivity(intent)
        }

    }

    fun updateScore(){
        score+=5
        binding.txtScore.text = "Score : $score poin"
    }

    fun randomQuestion(){
        var ctr = (0..17).random()
        binding.txtSoal.text = list_pertanyaan[ctr][0]
        currentQuestion = list_pertanyaan[ctr][0]
        currentAnswer = list_pertanyaan[ctr][1]
    }
}