package com.example.tm3_221180545

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageButton
import com.example.tm3_221180545.databinding.ActivityMainBinding
import com.example.tm3_221180545.databinding.ActivityReviewBinding

class ReviewActivity : AppCompatActivity() {
    private lateinit var binding: ActivityReviewBinding

    private lateinit var bintangBintang: MutableList<ImageButton>
    var reviewMessage = ""

    var rating = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_review)

        binding = ActivityReviewBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //start
        bintangBintang = mutableListOf(binding.star1, binding.star2, binding.star3, binding.star4, binding.star5)

        for (index in 0..bintangBintang.size-1){
            bintangBintang[index].setOnClickListener {
                // kita panggil supaya nanti bisa update bintang
                rating = index + 1
                updateBintang(rating)
            }
        }


        binding.btnFinish.setOnClickListener(){
            finish()
        }

        binding.btnSend.setOnClickListener(){
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("smsto:08123456789")
                putExtra("sms_body", "$rating ⭐: ${binding.edtReview.text.toString()}")
            }
            startActivity(intent)
        }
    }

    fun updateBintang(rating:Int) {
//        // clear dulu semua bintang
        for (b in bintangBintang) {
            b.setImageResource(R.drawable.star_empty)
        }
//        // kita Looping setiap bintang sampai sejumlah dengan ratingnya
        for(i in 0..rating - 1){
            bintangBintang[i].setImageResource(R.drawable.star_fill)
        }
    }

}