package com.example.tm3_221180545

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.RadioButton
import com.example.tm3_221180545.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding:ActivityMainBinding
    var kg = 0
    var totalPrice = 0
    var deliveryStatus = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //checkbox delivery
        var isDeliveryChecked = false
        binding.cbDelivery.setOnCheckedChangeListener { buttonView, isChecked ->
            isDeliveryChecked = isChecked //isChecked bergantung kondisi checkboxnya, kalo kecentang, isChecked = true and vice versa
            binding.edtAddress.isEnabled = isDeliveryChecked

            deliveryStatus = isChecked
            if (deliveryStatus == true){
                finalPrice(totalPrice)
            }
            else{
                totalPrice -= 5000
                binding.txtRp.text = "Rp. $totalPrice"
            }
        }

        //pengecekan btnPlus btnMinus
        binding.btnMinus.setOnClickListener {
            if (kg >= 1){
                kg--
            }
            changeKG()
            calculatePrice(binding.rdbCuciLipat, binding.rdbCuciSetrika, binding.rdbDryClean)
        }
        binding.btnPlus.setOnClickListener {
            kg++
            changeKG()
            calculatePrice(binding.rdbCuciLipat, binding.rdbCuciSetrika, binding.rdbDryClean)
        }


        //calculate harga
        binding.rdbCuciLipat.setOnCheckedChangeListener { buttonView, isChecked ->
            calculatePrice(binding.rdbCuciLipat, binding.rdbCuciSetrika, binding.rdbDryClean)
        }

        binding.rdbCuciSetrika.setOnCheckedChangeListener { buttonView, isChecked ->
            calculatePrice(binding.rdbCuciLipat, binding.rdbCuciSetrika, binding.rdbDryClean)
        }

        binding.rdbDryClean.setOnCheckedChangeListener { buttonView, isChecked ->
            calculatePrice(binding.rdbCuciLipat, binding.rdbCuciSetrika, binding.rdbDryClean)
        }

        //pindah halaman
        binding.btnOrder.setOnClickListener(){
            val intent = Intent(this, ReviewActivity::class.java)
            startActivity(intent)
        }

    }

    fun changeKG(){
        binding.txtKG.text = "$kg KG"
    }


    fun calculatePrice(rdbCuciLipat: RadioButton, rdbCuciSetrika: RadioButton, rdbDryClean: RadioButton) {
        var tempPrice = 0
        if (rdbCuciLipat.isChecked){
            tempPrice = kg * 10000
        }
        else if (rdbCuciSetrika.isChecked){
            tempPrice = kg * 15000
        }
        else if (rdbDryClean.isChecked){
            tempPrice = kg * 20000
        }
        finalPrice(tempPrice)
    }

    fun finalPrice(tempPrice: Int){
        if (deliveryStatus == true){
            totalPrice = tempPrice + 5000
        }
        else{
            totalPrice = tempPrice
        }
        binding.txtRp.text = "Rp. $totalPrice"
    }
}