package com.example.tm2_221180545

open class Aset(harga:Int, nama:String) {
    override fun toString(): String {
        return super.toString()
    }
}