package com.example.tm2_221180545

class Hutang() {
    var listNamaHutang = mutableListOf<String>("Pinjol Sudirman", "Spotify Family Lala", "Hutang Kost Gaby", "Hutang Negara", "Uang Jajan Rohingya", "Makan Siang Ibu Hamil", "Alutsista Bekas", "Kredit Wuling Kuning iSTTS")
    var rnd = (0..7).random()
    var nama = listNamaHutang[rnd]
    var nominalHutang = (300..1000).random()


    fun bayar(input:Int?){
        if (input != null){
            if (input > uang){ //jika inputan lebih besar dari duit
                print("You're poor. Go to work."); readln()
            }
            else{
                var temp = nominalHutang
                nominalHutang -= input
                if (nominalHutang < 0){
                    uang = uang - temp
                    nominalHutang = 0
                    print("Berhasil membayar $nama sebesar $$temp (Hutang anda sekarang : $$nominalHutang)");readln()
                }
                else{
                    uang -= input
                    print("Berhasil membayar $nama sebesar $$input (Hutang anda sekarang : $$nominalHutang)");readln()
                }
            }
        }
        else{
            print("Really bro?"); readln()
        }
    }

    fun rngBunga(){
        val probability = 5
        val rnd = (1..100).random()
        var totalBunga = nominalHutang * 0.2
        nominalHutang += totalBunga.toInt()

        if (rnd <= probability) {
            //kena bunga lol
            println("Terkena bunga $nama sebesar 20%! -> $$nominalHutang (+$$totalBunga)")
        }
    }
    override fun toString(): String {
        return "Nama hutang : $nama, Nominal hutang : $nominalHutang"
    }
}