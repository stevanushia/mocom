package com.example.tm2_221180545

class Saham(harga: Int, nama: String, jumlah: Int) : Aset(harga = harga, nama = nama) {
    var jumlah = jumlah
    var nama = nama
    var harga = harga
    var subtotal:Int = 0
        get() {
            return jumlah * harga
        }

    fun naikTurunSaham(){
        var rnd:Int = (1..2).random()
        when(rnd){
            1->{
                //naik 50%
                var kenaikan = (harga*0.5).toInt()
                harga += kenaikan
                println("Saham $nama naik! $nama -> $harga (+$kenaikan) ")
            }
            2->{
                //turun 25%
                var penurunan = (harga*0.25).toInt()
                harga -= penurunan
                println("Saham $nama turun! $nama -> $harga (-$penurunan) ")

            }
        }
    }

    override fun toString(): String {
        return super.toString()
    }
}