package com.example.tm2_221180545

import kotlin.time.times
var nama = ""
var uang:Int = 0
var listAsset = mutableListOf<Aset>()

var sahamABC = Saham(10, "ABC", 0)
var sahamBCA = Saham(10, "BCA", 0)
var sahamCAB = Saham(10, "CAB", 0)

var listSaham = mutableListOf<Aset>(sahamABC, sahamBCA, sahamCAB)
var listRumah = mutableListOf<Rumah>(Rumah(), Rumah())
var listHutang = mutableListOf<Hutang>(Hutang(), Hutang(), Hutang())

fun main(){
    //debug inisialisasi listRumah
//    for (i in listRumah){
//        println(i.toString())
//    }

    var isRunning = true
    while (isRunning){
        println("""
            ============= 
            Debt Escape 
            ============= 
            1. Start 
            2. Exit 
        """.trimIndent())
        print(">> "); var mainInput = readln().toIntOrNull()

        when (mainInput) {
            2 -> {
                isRunning = false
            }
            1 -> {
                //start logic
                var isGaming = true

                print("Masukkan nama: "); nama = readln()
                while (isGaming){
                    print("""
                        ==================== 
                        Hi, $nama (${uang.toDollar()}) 
                        ==================== 
                        1. Kerja 
                        2. Lihat Aset 
                        3. Bayar Hutang 
                        4. Next Month 
                        5. Exit 
                        >> 
                    """.trimIndent())
                    var gameInput = readln().toIntOrNull()

                    when (gameInput){
                        1->{
                            //kerja
                            kerja()
                        }
                        2->{
                            //lihat aset
                            lihatAset()

                        }
                        3->{
                            //bayar hutang
                            bayarHutang()
                        }
                        4->{
                            //next month?
                            print("uhh. . . ");readln()
                        }
                        5->{
                            //exit game
                            resetGame(listSaham)
                            isGaming = false
                        }
                        else->{
                            print("Invalid input!"); readln()
                        }
                    }
                }
            }
            else -> {
                println("""
                    There is no such option!
                    Press ENTER to continue...
                """.trimIndent()); readln()
            }
        }
    }
}

fun bayarHutang() {
    var isBayarHutang = true
    while (isBayarHutang){
        println("""
            Hutang
            Balance: $$uang
            ====================
        """.trimIndent())
        var ctr = 0
        for (i in listHutang){
            ctr++
            println("$ctr. ${i.nama} (${i.nominalHutang})")
        }
        print("""
            0.Cancel
            >>
        """.trimIndent())
        var input = readln().toIntOrNull()

        when(input){
            is Int->{
                if (input <= listHutang.size){
                    if (input == 0){
                        isBayarHutang = false
                    }
                    else{
                        var idxSelectedHutang = input-1
                        var selectedHutang = listHutang[idxSelectedHutang]

                        println("Bayar ${selectedHutang.nama} ($${selectedHutang.nominalHutang})")
                        print("Nominal : "); var nominalPembayaran:Int? = readln().toIntOrNull()

                        selectedHutang.bayar(nominalPembayaran)

                        if (selectedHutang.nominalHutang <= 0){
                            print("Selamat! ${selectedHutang.nama} telah lunas!")
                            listHutang.removeAt(idxSelectedHutang)
                            readln()
                        }
                    }
                }
                else{
                    print("Invalid input!")
                }
            }
            else->{
                print("Invalid input!")
            }
        }
    }
}



fun kerja(){
    var result: Int = 0
    var operator = ""
    var reward = 0

    println("""
        Kerja 
        ==================== 
    """.trimIndent())
    for (i in 1..5){
        var rnd1 = (1..50).random()
        var rnd2 = (1..50).random()
        var rndOperator = (1..3).random()
        when (rndOperator){
            1-> {
                result = rnd1 + rnd2
                operator = "+"
            }
            2->{
                result = rnd1 - rnd2
                operator = "-"
            }
            3->{
                result = rnd1 * rnd2
                operator = "x"
            }

        }
        print("${rnd1.toString()} $operator ${rnd2.toString()} = "); var answer = readln().toIntOrNull()
        if (answer == result){
            print("Correct! +$20"); readln()
            reward+=20
        }
        else{
            print("Wrong answer!"); readln()
        }
    }
    println("====================")
    println("Berhasil mendapatkan $$reward"); println()
    
    uang += reward //hasil kerja

    //list of event
    eventSaham()
    eventRumah()
    eventHutang()
    //list of event

    println()
    print("PRESS ENTER TO CONTINUE...")
    readln()
    println()
}

fun lihatAset(){
    var isRunning = true
    while (isRunning){
        print("""
            Assets 
            ==================== 
            1. Beli Saham 
            2. Beli Rumah 
            3. Jual Aset
            0. Cancel 
            >> 
        """.trimIndent())
        var inputLihatAset = readln().toIntOrNull()

        when(inputLihatAset){
            0->{
                isRunning = false
            }
            1->{
                //beli saham
                var isBuyingSaham = true
                while (isBuyingSaham){
                    print("""
                        Saham 
                        Balance: $$uang 
                        ==================== 
                        1. ABC - $${sahamABC.harga} (${sahamABC.jumlah} lot owned)
                        2. BCA - $${sahamBCA.harga} (${sahamBCA.jumlah} lot owned)
                        3. CAB - $${sahamCAB.harga} (${sahamCAB.jumlah} lot owned)
                        0. Cancel 
                        >>
                    """.trimIndent())
                    var inputBeliSaham = readln().toIntOrNull()
                    when(inputBeliSaham){
                        0 ->{
                            isBuyingSaham = false
                        }
                        1->{
                            //SAHAM ABC
                            beliSaham(sahamABC)
                        }
                        2->{
                            //SAHAM BCA
                            beliSaham(sahamBCA)

                        }
                        3->{
                            //SAHAM CAB
                            beliSaham(sahamCAB)
                        }
                    }
                }
            }
            2->{
                //Beli Rumah
                beliRumah()
            }
            3->{
                //Jual Aset
                jualAset()
            }
        }
    }
}

fun beliRumah() {
    var isBuyingHouse = true
    while (isBuyingHouse){
        println("""
            Rumah 
            Balance: $$uang 
            ==================== 
        """.trimIndent())
        var ctr = 0
        for (i in listRumah){
            ctr++
            if (i.bought){
                println("$ctr. ${i.nama} - $${i.harga} (Bought!)")
            }
            else{
                println("$ctr. ${i.nama} - $${i.harga}")

            }
        }
        print("""
            0. Cancel
            >> 
        """.trimIndent())
        var inputBuyingHouse = readln().toIntOrNull()

        when(inputBuyingHouse){
            is Int->{
                if (inputBuyingHouse == 0){
                    isBuyingHouse = false
                }
                else{
                    var idxSelectedHouse = inputBuyingHouse-1
                    var selectedHouse = listRumah[idxSelectedHouse]

                    var rumahKembar = false

                    for (i in listAsset){
                        if (i.equals(selectedHouse)){
                            rumahKembar = true
                            break
                        }
                    }

                    if (!rumahKembar){
                        if (selectedHouse.harga <= uang){
                            //uang cukup
                            uang -= selectedHouse.harga
                            selectedHouse.bought = true
                            listAsset.add(selectedHouse)
                            print("Successfully bought ${selectedHouse.nama} for ${selectedHouse.harga}!"); readln()
                            listRumah.add(Rumah())
                            print("There is a new house for you to buy!"); readln()

                        }
                        else{
                            //miskin
                            print("You're poor, go to work."); readln()
                        }
                    }
                    else{
                        print("You already bought this house, chill out."); readln()
                    }

                }
            }
            else->{
                print("Invalid input!"); readln()
            }
        }

    }
}

fun jualAset() {
    var isJualAset = true
    while (isJualAset){
        println("""
            Jual Aset 
            Balance: $uang 
            ==================== 
        """.trimIndent())
        var idx = 0
        for (i in listAsset){
            idx++
            when(i){
                is Saham->{
                    println("$idx. ${i.nama} (Saham) - ${i.jumlah} : Subtotal $${i.subtotal}; $${i.harga} each")
                }
                is Rumah->{
                    println("$idx. ${i.nama} (Rumah) - 1 : ${i.harga}")
                }
            }
        }
        println("0. Cancel")
        print(">> "); var inputJual = readln().toIntOrNull()
        when(inputJual){
            is Int->{
                if (inputJual == 0){
                    isJualAset = false
                }
                else{
                    var idxSelectedAsset = inputJual.minus(1)
                    var selectedAsset = listAsset[idxSelectedAsset]
                    var selectedSaham:Saham
                    var selectedRumah:Rumah


                    print("Jumlah yang ingin dijual: "); var jumlahJual = readln().toIntOrNull()
                    when(selectedAsset){
                        is Saham ->{
                            if (jumlahJual!! > selectedAsset.jumlah ){
                                print("Jumlah yang ingin dijual tidak boleh melebihi jumlah aset yang dimiliki!"); readln()
                            }
                            else{
                                selectedAsset.jumlah -= jumlahJual
                                print("Berhasil menjual ${selectedAsset.nama} seharga $${jumlahJual*selectedAsset.harga}"); readln()
                                uang += (jumlahJual * selectedAsset.harga)
                                if (selectedAsset.jumlah == 0){
                                    listAsset.removeAt(idxSelectedAsset)
                                }
                            }
                        }
                        is Rumah->{
                            if (jumlahJual!! > selectedAsset.jumlah ){
                                print("Jumlah yang ingin dijual tidak boleh melebihi jumlah aset yang dimiliki!"); readln()
                            }
                            else{
                                selectedAsset.jumlah -= jumlahJual
                                print("Berhasil menjual ${selectedAsset.nama} seharga ${jumlahJual*selectedAsset.harga}"); readln()
                                uang += (jumlahJual * selectedAsset.harga)
                                if (selectedAsset.jumlah == 0){
                                    listAsset.removeAt(idxSelectedAsset)
                                }
                            }
                        }
                    }


                }
            }
            else->{
                print("Invalid input!"); readln()
            }
        }
    }
}

fun beliSaham(saham: Saham){
    print("Jumlah: ");var jumlah:Int? = readln().toIntOrNull()
    if ((jumlah!!.times(saham.harga)) > uang){
        //miskin
        print("Uang anda tidak cukup!"); readln()
    }
    else{
        //sukses beli saham
        saham.jumlah += jumlah
        uang -= jumlah.times(saham.harga)

        var sahamKembar = false
        for (i in listAsset){
            if (i.equals(saham)){
                sahamKembar = true
                break
            }
        }

        if (!sahamKembar){
            listAsset.add(saham)
        }

        print("Sukses membeli saham ${saham.nama}!"); readln()
        println("Jumlah saham ${saham.nama} anda : ${saham.jumlah} lot")
        print("Total harga saham ${saham.nama} anda : $${saham.subtotal}")
        readln()
    }
}

fun eventSaham(){
    for (i in listSaham){
        when(i){
            is Saham ->{
                i.naikTurunSaham()
            }
        }
    }
}

fun eventHutang(){
    for (i in listHutang){
        i.rngBunga()
    }
}

fun eventRumah(){
    for (i in listAsset){
        when(i){
            is Rumah->{
                i.naikHarga()
            }
        }
    }
}

fun resetGame(saham: MutableList<Aset>){
    //reset list saham
    var hutang = 0
    var status = "Lose!"
    for (i in listHutang){
        hutang += i.nominalHutang
    }
    if (hutang == 0){
        status = "Win!"
    }

    println("""
        ====================
        Finished
        ====================
        $nama, 
        money in pocket: $$uang 
        debt: $$hutang
        You $status
    """.trimIndent())
    readln()

    for (i in saham){
        when (i){
            is Saham->{
                i.jumlah = 0
                i.harga = 10
            }
        }
    }

    //reset list asset
    listAsset.clear()

    //reset list rumah
    listRumah.clear()
    listRumah.add(Rumah())
    listRumah.add(Rumah())

    //reset list hutang
    listHutang.clear()
    listHutang.add(Hutang())
    listHutang.add(Hutang())
    listHutang.add(Hutang())

    //reset uang
    uang = 0
}

fun Int.toDollar():String{
    return "$$this"
}
