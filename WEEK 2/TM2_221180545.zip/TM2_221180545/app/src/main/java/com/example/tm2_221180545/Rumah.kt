package com.example.tm2_221180545

class Rumah(harga: Int = (300..700).random(), nama: String = "Rumah " + ('A'..'Z').random().toString(), jumlah: Int = 1) : Aset(harga, nama) {
    var jumlah = jumlah
    var nama = nama
    var harga = harga
    var bought = false

    fun naikHarga(){
        harga += 50
        println("Harga $nama naik! $nama -> $$harga (+$50)")
    }
    override fun toString(): String {
        return "Nama : $nama, Harga: $harga"
    }
}