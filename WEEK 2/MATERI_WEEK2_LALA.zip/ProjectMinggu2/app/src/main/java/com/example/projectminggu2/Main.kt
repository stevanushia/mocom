package com.example.projectminggu2

import kotlin.concurrent.timer
import kotlin.random.Random

fun main(){
//    var mhs:Mahasiswa = Mahasiswa("Lala")
//    println(mhs.toString())
//
//    println("List Mhs size : " + Mahasiswa.listMhs.size)
//    Mahasiswa.addToList(mhs)
//    println("List Mhs size : " + Mahasiswa.listMhs.size)
//    println(Mahasiswa.listMhs)


    var menu = true
    while (menu){
        println()
        print("""
            Potion
            1.	Add Page
            2.	List Page
            3.	Exit
            >> 
        """.trimIndent())
        var inp_menu = readln().toIntOrNull() ?: 0
        if (inp_menu == 1){
            print("""
                New page
                Logo: 
            """.trimIndent())
            var logo = readln()
            print("Nama: ")
            var nama = readln()

            var p:Page
            if (logo.length <= 0)  p = Page(nama) else p = Page(nama , logo.toCharArray()[0])
            Page.listPage.add(p)
            println("'${nama}' has been created.")
        }
        else if (inp_menu == 2){
            myPages()
        }
        else if (inp_menu == 3){
            menu = false
        }
    }
}

fun myPages(){
    var menu = true
    while (menu){
        println("My pages")
        for (i in 0..Page.listPage.size-1){
            println("${i+1}. ${Page.listPage[i].nama}")
        }
        print("0. Exit\n>> ")
        var inp = readln()
        if (inp == "0"){
            menu = false
        }
        else
        {
            var x = inp.toInt() - 1
            Page.listPage[x].detailPage()
        }
    }
}

//class Mahasiswa(var nama:String, var NRP:String = "0123456789", var umur:Int? = 18){
//    var rand = Random(1).nextInt() * 10000
//    init {
//        this.NRP = "22118$rand"
//    }
//
//    var IPK:Float = 2.6f
//        get() = field + 1.0f
//
//    // ctrl+O
//    override fun toString(): String {
//        return "Nama ${this.nama} ($umur thn) - $NRP"
//    }
//
//    // STATIC
//    companion object{
//        var listMhs = mutableListOf<Mahasiswa>()
//        fun addToList(mhs:Mahasiswa){
//            listMhs.add(mhs)
//        }
//    }
//}