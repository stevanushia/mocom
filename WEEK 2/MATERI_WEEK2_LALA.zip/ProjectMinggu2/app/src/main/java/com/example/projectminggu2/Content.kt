package com.example.projectminggu2

class Content(var isi:String) {
    override fun toString(): String {
        return this.isi
    }
}