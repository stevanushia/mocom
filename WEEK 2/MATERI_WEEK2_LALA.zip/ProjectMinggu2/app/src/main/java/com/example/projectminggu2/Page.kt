package com.example.projectminggu2

class Page (var nama:String, var logo:Char? = ' ') {
    var listContent:MutableList<Content> = mutableListOf<Content>()

//    override fun toString(): String {
//        return """${this.logo} ${this.nama}""".trimIndent()
//    }

    fun detailPage(){
        var detail = true
        while (detail){
            println("\n${this.logo} ${this.nama}")
            for ((idx,c) in listContent.withIndex()){
                println("${idx + 1} ${c.isi}")
            }
            print(">> ")
            var inp = readln()
            if (inp == "add") {
                print("Isi: ")
                var isi = readln()
                addContent(Content(isi))
            }
            else if (inp == "delete") {
                listPage.remove(this)
            }
            else if (inp == "back") {
                detail = false
            }
            else {
                var x = inp.toInt()
                print("""
                    Isi: ${listContent[x-1].toString()}
                    1. Sambung
                    2. Ubah
                    3. Hapus
                    0. Back
                    >> 
                """.trimIndent())
                var edit = readln()
                if (edit == "0") {
                    return
                }
                else if (edit == "1") {
                    print("Isi sambungan: ")
                    var new = readln()
                    listContent[x-1] = Content("${listContent[x-1]} $new")
                    val updated = "${listContent[x-1]} $new"
                    println("""
                        Berhasil menambah text!
                        Text Baru: ${listContent[x-1].toString()}
                    """.trimIndent())
                }
                else if (edit == "2") {
                    print("Isi baru: ")
                    var new = readln()
                    listContent[x-1] = Content(new)
                    println("""
                        Berhasil mengubah text!
                        Text Baru: ${new}
                    """.trimIndent())
                }
                else if (edit == "3") {
                    listContent.removeAt(x-1)
                }
            }
        }
    }

    fun addContent(isi:Content){
        listContent.add(isi)
    }

    companion object{
        var listPage = mutableListOf<Page>()
//        fun addPage(page:Page){
//            listPage.add(page)
//        }
    }
}