package com.example.basictutorm4

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class SampleAdapter(val listMhs: MutableList<Mahasiswa>, val layout:Int) : RecyclerView.Adapter<SampleViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SampleViewHolder {
        val item = LayoutInflater.from(parent.context)
        return SampleViewHolder(
            item.inflate(layout, parent, false)
        )
    }

    override fun getItemCount(): Int {
        return listMhs.size
    }

    override fun onBindViewHolder(holder: SampleViewHolder, position: Int) {
        holder.tvNRP.text = listMhs[position].nrp
        holder.tvNama.text = listMhs[position].nama
    }
}

class SampleViewHolder(viewku:View) :RecyclerView.ViewHolder(viewku){
    val tvNRP:TextView = viewku.findViewById(R.id.tvNRPItem3)
    val tvNama:TextView = viewku.findViewById(R.id.tvNamaItem3)
}