package com.example.basictutorm4

data class Mahasiswa(
    val nrp: String,
    var nama: String,
    var jurusan: Int
)
