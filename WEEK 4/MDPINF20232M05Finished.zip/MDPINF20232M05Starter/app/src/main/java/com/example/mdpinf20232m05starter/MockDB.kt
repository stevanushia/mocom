package com.example.mdpinf20232m05starter

object MockDB {
    val students:ArrayList<Student> = ArrayList()
}