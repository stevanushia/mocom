package com.example.mdpinf20232m05starter

data class Student(
    val nrp:String,
    var name:String,
    var ipk:Double
)