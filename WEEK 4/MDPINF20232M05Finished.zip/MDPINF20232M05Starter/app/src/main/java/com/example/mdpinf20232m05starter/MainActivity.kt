package com.example.mdpinf20232m05starter

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.mdpinf20232m05starter.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    lateinit var binding:ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val students:ArrayList<Student> = MockDB.students
        students.add(Student("221000000", "Anne", 2.0))
        students.add(Student("221000001", "Beatrice", 2.5))
        students.add(Student("221000002", "Clara", 3.0))
        students.add(Student("221000003", "Diana", 3.5))
        students.add(Student("221000004", "Ellaine", 4.0))

        val studentAdapter = StudentAdapter(students){student ->
            binding.nrpEtMain.setText(student.nrp)
            binding.nameEtMain.setText(student.name)
            binding.ipkEtMain.setText(student.ipk.toString())
        }

        binding.studentsRvMain.adapter = studentAdapter
        binding.studentsRvMain.layoutManager = LinearLayoutManager(this,
            LinearLayoutManager.VERTICAL, false)
//        binding.studentsRvMain.layoutManager = LinearLayoutManager(this,
//            LinearLayoutManager.HORIZONTAL, false)
//        binding.studentsRvMain.layoutManager = GridLayoutManager(
//            this, 2, GridLayoutManager.HORIZONTAL, false)

        binding.putBtnMain.setOnClickListener {
            val nrp = binding.nrpEtMain.text.toString()
            val nama = binding.nameEtMain.text.toString()
            val ipk = binding.ipkEtMain.text.toString().toDouble()

            var ketemu = false
            for((i, s) in students.withIndex()){
                if(s.nrp == nrp){
                    s.name = nama
                    s.ipk = ipk
                    ketemu = true
                    studentAdapter.notifyItemChanged(i)
                }
            }
            if(!ketemu){
                students.add(Student(nrp, nama, ipk))
                studentAdapter.notifyItemInserted(students.size - 1)
            }
        }

        binding.shuffleBtnMain.setOnClickListener {
            students.shuffle()
            studentAdapter.notifyDataSetChanged()
        }

        binding.sortBtnMain.setOnClickListener {
            students.sortBy {
                it.nrp
            }
            studentAdapter.notifyDataSetChanged()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.opt_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.star_mi -> {
                Toast.makeText(this, "star", Toast.LENGTH_SHORT).show()
                return true
            }
            R.id.menu1_mi -> {
                Toast.makeText(this, "menu 1", Toast.LENGTH_SHORT).show()
                return true
            }
        }
        return false
    }
}